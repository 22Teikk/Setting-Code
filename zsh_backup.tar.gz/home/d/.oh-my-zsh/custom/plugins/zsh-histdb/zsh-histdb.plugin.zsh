source ${0:A:h}/sqlite-history.zsh
