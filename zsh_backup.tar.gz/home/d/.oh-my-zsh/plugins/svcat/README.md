# svcat

This plugin provides completion for the [Kubernetes service catalog cli](https://github.com/kubernetes-incubator/service-catalog).

To use it, add `svcat` to the plugins array in your zshrc file.

```
plugins=(... svcat)
```
